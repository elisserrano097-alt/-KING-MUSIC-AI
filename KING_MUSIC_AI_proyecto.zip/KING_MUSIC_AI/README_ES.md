
# KING MUSIC AI — proyecto inicial Android + servidor IA

Este paquete contiene:
- Aplicación Android nativa (Java + WebView) con interfaz local.
- Interfaz web responsive para crear canciones y guardar una biblioteca local.
- Servidor Node.js que protege la clave del proveedor de música.
- Integración inicial con Google Gemini API / modelo Lyria 3.5 mediante `@google/genai`.

## Importante
Este paquete es el **proyecto fuente**, no un APK ya compilado. En este entorno no están instalados Android SDK, Android Gradle Plugin ni las herramientas de compilación, así que no puedo producir ni verificar un APK instalable aquí. Puedes abrir `android/` en Android Studio y compilarlo siguiendo los pasos de abajo.

La generación musical real necesita:
1. Crear una clave de API en Google AI Studio y confirmar que tu cuenta tiene acceso al modelo Lyria.
2. Desplegar `server/` en un servicio HTTPS (Render, Railway, Fly.io, VPS, etc.).
3. Poner la URL HTTPS del servidor en la pantalla Configuración de la app.

No pongas la clave de Google dentro de la APK. El servidor la guarda en una variable de entorno.

## Probar el servidor
Requiere Node.js 20 o superior.

```bash
cd server
cp .env.example .env
# Edita .env y coloca GEMINI_API_KEY
npm install
npm start
```

El servidor escucha en `http://localhost:8787`. Para uso real desde el teléfono, publícalo detrás de HTTPS.

## Abrir y compilar Android
1. Instala Android Studio.
2. Abre la carpeta `android/` (no la carpeta raíz).
3. Deja que Gradle sincronice el proyecto.
4. Conecta un Android o crea un emulador.
5. Menú **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio mostrará la ubicación del APK generado.

La app usa `minSdk 23` y apunta a Android moderno. Para publicar en Play Store habrá que completar nombre legal, iconos, política de privacidad, términos y pruebas.

## Estado de esta primera versión
- Interfaz: lista para probar.
- Ajustes de URL del backend: incluidos.
- Biblioteca: guardado local del navegador/WebView.
- Generación real: requiere clave, acceso al modelo y servidor desplegado.
- No incluye clonación de voces ni imitación de artistas. Usa voces/estilos permitidos por el proveedor.
