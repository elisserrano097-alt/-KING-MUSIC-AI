
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { GoogleGenAI } from '@google/genai';

const app = express();
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || '*' }));
app.use(express.json({ limit: '2mb' }));

const ai = process.env.GEMINI_API_KEY
  ? new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY })
  : null;

app.get('/health', (_req, res) => {
  res.json({ ok: true, app: 'KING MUSIC AI', providerConfigured: Boolean(ai) });
});

app.post('/api/generate', async (req, res) => {
  try {
    if (!ai) return res.status(503).json({ error: 'El servidor todavía no tiene GEMINI_API_KEY configurada.' });

    const {
      prompt = '', lyrics = '', genre = 'Reguetón', bpm = 100,
      mood = 'Energético', voice = 'Voz masculina', instrumental = false,
      title = 'Nueva canción'
    } = req.body || {};

    if (!String(prompt).trim() && !String(lyrics).trim()) {
      return res.status(400).json({ error: 'Escribe una descripción o agrega una letra.' });
    }

    const direction = [
      `Create an original ${genre} song.`,
      `Mood: ${mood}. Tempo: approximately ${Number(bpm) || 100} BPM.`,
      instrumental ? 'Instrumental only, no vocals.' : `Vocal direction: ${voice}.`,
      `Title: ${title}.`,
      prompt ? `Production direction: ${prompt}` : '',
      lyrics && !instrumental ? `Use these original lyrics as the song lyrics:\n${lyrics}` : '',
      'Make the arrangement musical, coherent, polished, and original. Do not imitate a specific artist.'
    ].filter(Boolean).join('\n');

    // Lyria 3.5 is accessed through the Gemini Interactions API.
    const result = await ai.interactions.create({
      model: 'lyria-3.5',
      input: direction
    });

    const audio = result?.outputAudio?.data || result?.output_audio?.data;
    const mimeType = result?.outputAudio?.mimeType || result?.output_audio?.mime_type || 'audio/mpeg';

    if (!audio) {
      return res.status(502).json({
        error: 'El proveedor no devolvió audio en el formato esperado. Revisa el acceso a Lyria y la versión del SDK.',
        providerResponse: result
      });
    }

    res.json({ title, mimeType, audioBase64: audio });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err?.message || 'Error al generar la canción.' });
  }
});

const port = Number(process.env.PORT || 8787);
app.listen(port, () => console.log(`KING MUSIC AI server listening on ${port}`));
